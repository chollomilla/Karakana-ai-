import {
  boolean,
  datetime,
  decimal,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing independent email/password authentication. */
export const users = mysqlTable(
  "users",
  {
    id: int("id").autoincrement().primaryKey(),
    email: varchar("email", { length: 320 }).notNull(),
    passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
    name: text("name"),
    loginMethod: varchar("loginMethod", { length: 64 }).default("password").notNull(),
    role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  },
  table => [uniqueIndex("users_email_unique").on(table.email)]
);

export const tenants = mysqlTable(
  "tenants",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    ownerUserId: int("ownerUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("tenants_owner_user_unique").on(table.ownerUserId)]
);

export const profiles = mysqlTable(
  "profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    userId: int("userId").notNull(),
    businessName: varchar("businessName", { length: 160 }).notNull(),
    businessContext: text("businessContext"),
    preferredLanguage: varchar("preferredLanguage", { length: 16 })
      .default("sw")
      .notNull(),
    currency: varchar("currency", { length: 8 }).default("TZS").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("profiles_tenant_user_unique").on(table.tenantId, table.userId),
    index("profiles_user_idx").on(table.userId),
  ]
);

export const products = mysqlTable(
  "products",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    name: varchar("name", { length: 180 }).notNull(),
    description: text("description"),
    price: decimal("price", { precision: 12, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 8 }).default("TZS").notNull(),
    stockQuantity: int("stockQuantity").default(0).notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("products_tenant_idx").on(table.tenantId)]
);

export const leads = mysqlTable(
  "leads",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    customerName: varchar("customerName", { length: 160 }).notNull(),
    customerPhone: varchar("customerPhone", { length: 48 }),
    source: mysqlEnum("source", ["whatsapp", "instagram", "other"])
      .default("whatsapp")
      .notNull(),
    stage: mysqlEnum("stage", ["new", "contacted", "interested", "negotiating", "won", "lost"])
      .default("new")
      .notNull(),
    leadScore: int("leadScore").default(0).notNull(),
    lastMessagePreview: text("lastMessagePreview").notNull(),
    nextAction: text("nextAction"),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("leads_tenant_updated_idx").on(table.tenantId, table.updatedAt),
    index("leads_tenant_score_idx").on(table.tenantId, table.leadScore),
  ]
);

export const messages = mysqlTable(
  "messages",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    leadId: int("leadId").notNull(),
    direction: mysqlEnum("direction", ["customer", "recommended", "agent"])
      .notNull(),
    content: text("content").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("messages_tenant_lead_created_idx").on(table.tenantId, table.leadId, table.createdAt)]
);

export const followUps = mysqlTable(
  "followUps",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    leadId: int("leadId").notNull(),
    action: text("action").notNull(),
    dueAt: datetime("dueAt").notNull(),
    status: mysqlEnum("status", ["scheduled", "due", "completed", "cancelled"])
      .default("scheduled")
      .notNull(),
    reminderSentAt: datetime("reminderSentAt"),
    completedAt: datetime("completedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("followups_due_idx").on(table.status, table.dueAt),
    index("followups_tenant_lead_idx").on(table.tenantId, table.leadId),
  ]
);

export const aiRuns = mysqlTable(
  "aiRuns",
  {
    id: int("id").autoincrement().primaryKey(),
    tenantId: int("tenantId").notNull(),
    leadId: int("leadId"),
    requestedByUserId: int("requestedByUserId").notNull(),
    status: mysqlEnum("status", ["succeeded", "failed"]).notNull(),
    model: varchar("model", { length: 80 }).notNull(),
    inputMessage: text("inputMessage").notNull(),
    output: json("output"),
    errorMessage: text("errorMessage"),
    durationMs: int("durationMs"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("ai_runs_tenant_created_idx").on(table.tenantId, table.createdAt)]
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Tenant = typeof tenants.$inferSelect;
export type Profile = typeof profiles.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Lead = typeof leads.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type FollowUp = typeof followUps.$inferSelect;
export type AiRun = typeof aiRuns.$inferSelect;
