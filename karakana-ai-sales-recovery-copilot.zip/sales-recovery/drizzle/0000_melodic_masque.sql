CREATE TABLE `aiRuns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`leadId` int,
	`requestedByUserId` int NOT NULL,
	`status` enum('succeeded','failed') NOT NULL,
	`model` varchar(80) NOT NULL,
	`inputMessage` text NOT NULL,
	`output` json,
	`errorMessage` text,
	`durationMs` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `aiRuns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `followUps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`leadId` int NOT NULL,
	`action` text NOT NULL,
	`dueAt` datetime NOT NULL,
	`status` enum('scheduled','due','completed','cancelled') NOT NULL DEFAULT 'scheduled',
	`reminderSentAt` datetime,
	`completedAt` datetime,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `followUps_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `leads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`customerName` varchar(160) NOT NULL,
	`customerPhone` varchar(48),
	`source` enum('whatsapp','instagram','other') NOT NULL DEFAULT 'whatsapp',
	`stage` enum('new','contacted','interested','negotiating','won','lost') NOT NULL DEFAULT 'new',
	`leadScore` int NOT NULL DEFAULT 0,
	`lastMessagePreview` text NOT NULL,
	`nextAction` text,
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `leads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`leadId` int NOT NULL,
	`direction` enum('customer','recommended','agent') NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`name` varchar(180) NOT NULL,
	`description` text,
	`price` decimal(12,2) NOT NULL,
	`currency` varchar(8) NOT NULL DEFAULT 'TZS',
	`stockQuantity` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`tenantId` int NOT NULL,
	`userId` int NOT NULL,
	`businessName` varchar(160) NOT NULL,
	`businessContext` text,
	`preferredLanguage` varchar(16) NOT NULL DEFAULT 'sw',
	`currency` varchar(8) NOT NULL DEFAULT 'TZS',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `profiles_tenant_user_unique` UNIQUE(`tenantId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `tenants` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`ownerUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tenants_id` PRIMARY KEY(`id`),
	CONSTRAINT `tenants_owner_user_unique` UNIQUE(`ownerUserId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`name` text,
	`loginMethod` varchar(64) NOT NULL DEFAULT 'password',
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE INDEX `ai_runs_tenant_created_idx` ON `aiRuns` (`tenantId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `followups_due_idx` ON `followUps` (`status`,`dueAt`);--> statement-breakpoint
CREATE INDEX `followups_tenant_lead_idx` ON `followUps` (`tenantId`,`leadId`);--> statement-breakpoint
CREATE INDEX `leads_tenant_updated_idx` ON `leads` (`tenantId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `leads_tenant_score_idx` ON `leads` (`tenantId`,`leadScore`);--> statement-breakpoint
CREATE INDEX `messages_tenant_lead_created_idx` ON `messages` (`tenantId`,`leadId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `products_tenant_idx` ON `products` (`tenantId`);--> statement-breakpoint
CREATE INDEX `profiles_user_idx` ON `profiles` (`userId`);