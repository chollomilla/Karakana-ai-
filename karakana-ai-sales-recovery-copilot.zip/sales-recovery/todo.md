# Project TODO

- [x] Review the supplied starter content and audit the initialized project for implementation and build gaps.
- [ ] Preserve and refine the sophisticated editorial interface: cream ground, Didone headline, lighter serif supporting type, geometric linework, and asymmetric whitespace.
- [ ] Define and implement tenant-scoped persistence for tenant profiles, products, leads, messages, follow-ups, and AI run records in Supabase.
- [ ] Add secure server-side configuration for Supabase and the AI service without exposing credentials in browser code.
- [ ] Build the customer-message analysis workflow that returns an AI analysis, recommended reply, and lead score.
- [ ] Persist saved leads, related message history, AI run records, and follow-up status and due date.
- [ ] Implement a durable scheduled follow-up reminder workflow for due recovery actions.
- [ ] Add automated tests covering validation, AI result handling, tenant scoping, and follow-up scheduling.
- [ ] Run database migration, type checks, tests, and production build; fix all discovered errors.
- [ ] Perform browser-based workflow verification and save the completed project checkpoint.
- [ ] Replace the blocked Supabase dependency with the project-managed database while retaining strict tenant scoping for all business records.
