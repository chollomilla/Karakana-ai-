import { TRPCError } from "@trpc/server";
import { and, desc, eq, inArray, isNull, lte } from "drizzle-orm";
import { z } from "zod";
import {
  aiRuns,
  followUps,
  leads,
  messages,
  products,
  profiles,
  tenants,
  users,
  type User,
} from "../drizzle/schema";
import { getDb } from "./db";
import { invokeLLM } from "./_core/llm";
import { sendReminderEmail } from "./_core/notification";
import { ENV } from "./_core/env";

const AI_MODEL = ENV.openaiModel;

const analysisShape = {
  type: "object",
  properties: {
    intent: { type: "string", description: "The customer's primary buying intent." },
    leadScore: { type: "integer", minimum: 0, maximum: 100 },
    recommendedReply: { type: "string", description: "A concise send-ready reply." },
    nextAction: { type: "string", description: "The most valuable next recovery action." },
    suggestedFollowUpHours: { type: "integer", minimum: 1, maximum: 168 },
    detectedProduct: { type: "string", description: "A product name from the catalog, or an empty string." },
    rationale: { type: "string", description: "A short reason for the score and recommendation." },
  },
  required: [
    "intent",
    "leadScore",
    "recommendedReply",
    "nextAction",
    "suggestedFollowUpHours",
    "detectedProduct",
    "rationale",
  ],
  additionalProperties: false,
} as const;

export const analysisResultSchema = z.object({
  intent: z.string().trim().min(1).max(160),
  leadScore: z.number().int().min(0).max(100),
  recommendedReply: z.string().trim().min(1).max(2500),
  nextAction: z.string().trim().min(1).max(500),
  suggestedFollowUpHours: z.number().int().min(1).max(168),
  detectedProduct: z.string().trim().max(180),
  rationale: z.string().trim().min(1).max(600),
});

export type AnalysisResult = z.infer<typeof analysisResultSchema>;

const requireDatabase = async () => {
  const database = await getDb();
  if (!database) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "The sales workspace database is temporarily unavailable.",
    });
  }
  return database;
};

const getTextContent = (content: unknown): string => {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map(part => (part && typeof part === "object" && "text" in part ? String(part.text) : ""))
      .join("");
  }
  return "";
};

const defaultBusinessName = (user: User) =>
  user.name?.trim() ? `${user.name.trim()}'s Business` : "My Sales Workspace";

export async function getWorkspace(user: User) {
  const database = await requireDatabase();
  let tenant = (
    await database.select().from(tenants).where(eq(tenants.ownerUserId, user.id)).limit(1)
  )[0];

  if (!tenant) {
    await database.insert(tenants).values({
      name: defaultBusinessName(user),
      ownerUserId: user.id,
    });
    tenant = (
      await database.select().from(tenants).where(eq(tenants.ownerUserId, user.id)).limit(1)
    )[0];
  }

  if (!tenant) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not create a sales workspace." });
  }

  let profile = (
    await database
      .select()
      .from(profiles)
      .where(and(eq(profiles.tenantId, tenant.id), eq(profiles.userId, user.id)))
      .limit(1)
  )[0];

  if (!profile) {
    await database.insert(profiles).values({
      tenantId: tenant.id,
      userId: user.id,
      businessName: tenant.name,
    });
    profile = (
      await database
        .select()
        .from(profiles)
        .where(and(eq(profiles.tenantId, tenant.id), eq(profiles.userId, user.id)))
        .limit(1)
    )[0];
  }

  if (!profile) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not create a business profile." });
  }

  return { database, tenant, profile };
}

export async function getRecoveryDashboard(user: User) {
  const { database, tenant, profile } = await getWorkspace(user);
  const [leadRows, followUpRows, productRows] = await Promise.all([
    database.select().from(leads).where(eq(leads.tenantId, tenant.id)).orderBy(desc(leads.updatedAt)),
    database
      .select()
      .from(followUps)
      .where(and(eq(followUps.tenantId, tenant.id), inArray(followUps.status, ["scheduled", "due"])))
      .orderBy(followUps.dueAt),
    database.select().from(products).where(eq(products.tenantId, tenant.id)).orderBy(desc(products.updatedAt)),
  ]);

  const now = new Date();
  const dueCount = followUpRows.filter(item => item.dueAt.getTime() <= now.getTime()).length;
  const hotLeadCount = leadRows.filter(lead => lead.leadScore >= 70 && !["won", "lost"].includes(lead.stage)).length;
  const followUpsByLead = new Map<number, (typeof followUpRows)[number]>();
  for (const followUp of followUpRows) {
    if (!followUpsByLead.has(followUp.leadId)) followUpsByLead.set(followUp.leadId, followUp);
  }

  return {
    tenant,
    profile,
    products: productRows,
    leads: leadRows.map(lead => ({ ...lead, followUp: followUpsByLead.get(lead.id) ?? null })),
    followUps: followUpRows,
    metrics: {
      hotLeadCount,
      dueFollowUpCount: dueCount,
      totalLeadCount: leadRows.length,
      activeProductCount: productRows.filter(product => product.isActive).length,
    },
  };
}

export async function getLeadDetail(user: User, leadId: number) {
  const { database, tenant } = await getWorkspace(user);
  const lead = (
    await database
      .select()
      .from(leads)
      .where(and(eq(leads.id, leadId), eq(leads.tenantId, tenant.id)))
      .limit(1)
  )[0];
  if (!lead) throw new TRPCError({ code: "NOT_FOUND", message: "Lead not found in this workspace." });

  const [messageRows, followUpRows] = await Promise.all([
    database
      .select()
      .from(messages)
      .where(and(eq(messages.leadId, lead.id), eq(messages.tenantId, tenant.id)))
      .orderBy(messages.createdAt),
    database
      .select()
      .from(followUps)
      .where(and(eq(followUps.leadId, lead.id), eq(followUps.tenantId, tenant.id)))
      .orderBy(desc(followUps.updatedAt)),
  ]);

  return { lead, messages: messageRows, followUps: followUpRows };
}

export async function updateBusinessProfile(
  user: User,
  input: { businessName: string; businessContext?: string; preferredLanguage: string; currency: string }
) {
  const { database, tenant, profile } = await getWorkspace(user);
  await database
    .update(profiles)
    .set({
      businessName: input.businessName,
      businessContext: input.businessContext?.trim() || null,
      preferredLanguage: input.preferredLanguage,
      currency: input.currency,
    })
    .where(and(eq(profiles.id, profile.id), eq(profiles.tenantId, tenant.id)));
  await database.update(tenants).set({ name: input.businessName }).where(eq(tenants.id, tenant.id));
  return (
    await database.select().from(profiles).where(eq(profiles.id, profile.id)).limit(1)
  )[0];
}

export async function createProduct(
  user: User,
  input: { name: string; description?: string; price: number; stockQuantity: number }
) {
  const { database, tenant, profile } = await getWorkspace(user);
  await database.insert(products).values({
    tenantId: tenant.id,
    name: input.name,
    description: input.description?.trim() || null,
    price: input.price.toFixed(2),
    stockQuantity: input.stockQuantity,
    currency: profile.currency,
  });
  return (
    await database
      .select()
      .from(products)
      .where(and(eq(products.tenantId, tenant.id), eq(products.name, input.name)))
      .orderBy(desc(products.id))
      .limit(1)
  )[0];
}

export async function analyzeCustomerMessage(user: User, message: string): Promise<AnalysisResult> {
  const { database, tenant, profile } = await getWorkspace(user);
  const catalog = await database
    .select()
    .from(products)
    .where(and(eq(products.tenantId, tenant.id), eq(products.isActive, true)));
  const catalogContext = catalog.length
    ? catalog
        .slice(0, 40)
        .map(product => `${product.name} | ${profile.currency} ${product.price} | stock ${product.stockQuantity}${product.description ? ` | ${product.description}` : ""}`)
        .join("\n")
    : "No catalog products have been entered yet.";
  const startedAt = Date.now();

  try {
    const response = await invokeLLM({
      model: AI_MODEL,
      maxTokens: 900,
      response_format: {
        type: "json_schema",
        json_schema: { name: "sales_recovery_analysis", strict: true, schema: analysisShape },
      },
      messages: [
        {
          role: "system",
          content: [
            "You are Karakana AI, a careful sales-recovery copilot.",
            "Write a warm, concise recommended reply in the same language as the customer when practical.",
            "Use only the catalog and business facts provided. Never claim a price, stock level, delivery policy, promotion, or product fact that is not present.",
            "If the customer asks for unavailable information, acknowledge it and ask the shortest useful follow-up question.",
            "Lead score measures conversion intent, not customer worth. Use the whole 0-100 range.",
            `Business: ${profile.businessName}. Preferred language: ${profile.preferredLanguage}.`,
            profile.businessContext ? `Business context: ${profile.businessContext}` : "",
            `Catalog:\n${catalogContext}`,
          ]
            .filter(Boolean)
            .join("\n\n"),
        },
        { role: "user", content: `Customer message:\n${message}` },
      ],
    });
    const text = getTextContent(response.choices[0]?.message.content);
    const analysis = analysisResultSchema.parse(JSON.parse(text));
    await database.insert(aiRuns).values({
      tenantId: tenant.id,
      requestedByUserId: user.id,
      status: "succeeded",
      model: response.model || AI_MODEL,
      inputMessage: message,
      output: analysis,
      durationMs: Date.now() - startedAt,
    });
    return analysis;
  } catch (error) {
    const messageText = error instanceof Error ? error.message.slice(0, 2000) : "Unknown AI analysis error";
    await database.insert(aiRuns).values({
      tenantId: tenant.id,
      requestedByUserId: user.id,
      status: "failed",
      model: AI_MODEL,
      inputMessage: message,
      errorMessage: messageText,
      durationMs: Date.now() - startedAt,
    });
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "The AI analysis could not be completed. Please try again.",
      cause: error,
    });
  }
}

export async function saveRecoveredLead(
  user: User,
  input: {
    customerName: string;
    customerPhone?: string;
    source: "whatsapp" | "instagram" | "other";
    customerMessage: string;
    analysis: AnalysisResult;
    followUpAt: Date;
  }
) {
  const { database, tenant } = await getWorkspace(user);
  const stage = input.analysis.leadScore >= 70 ? "interested" : "new";
  await database.insert(leads).values({
    tenantId: tenant.id,
    customerName: input.customerName,
    customerPhone: input.customerPhone?.trim() || null,
    source: input.source,
    stage,
    leadScore: input.analysis.leadScore,
    lastMessagePreview: input.customerMessage,
    nextAction: input.analysis.nextAction,
    createdByUserId: user.id,
  });
  const lead = (
    await database
      .select()
      .from(leads)
      .where(
        and(
          eq(leads.tenantId, tenant.id),
          eq(leads.customerName, input.customerName),
          eq(leads.createdByUserId, user.id)
        )
      )
      .orderBy(desc(leads.id))
      .limit(1)
  )[0];
  if (!lead) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not save this lead." });

  await database.insert(messages).values([
    { tenantId: tenant.id, leadId: lead.id, direction: "customer", content: input.customerMessage },
    { tenantId: tenant.id, leadId: lead.id, direction: "recommended", content: input.analysis.recommendedReply },
  ]);
  await database.insert(followUps).values({
    tenantId: tenant.id,
    leadId: lead.id,
    action: input.analysis.nextAction,
    dueAt: input.followUpAt,
    status: "scheduled",
  });

  return getLeadDetail(user, lead.id);
}

export async function updateLeadFollowUp(
  user: User,
  input: { followUpId: number; dueAt: Date; status: "scheduled" | "completed" | "cancelled"; action: string }
) {
  const { database, tenant } = await getWorkspace(user);
  const followUp = (
    await database
      .select()
      .from(followUps)
      .where(and(eq(followUps.id, input.followUpId), eq(followUps.tenantId, tenant.id)))
      .limit(1)
  )[0];
  if (!followUp) throw new TRPCError({ code: "NOT_FOUND", message: "Follow-up not found in this workspace." });

  await database
    .update(followUps)
    .set({
      action: input.action,
      dueAt: input.dueAt,
      status: input.status,
      completedAt: input.status === "completed" ? new Date() : null,
      reminderSentAt: input.status === "scheduled" ? null : followUp.reminderSentAt,
    })
    .where(and(eq(followUps.id, followUp.id), eq(followUps.tenantId, tenant.id)));

  return (
    await database.select().from(followUps).where(eq(followUps.id, followUp.id)).limit(1)
  )[0];
}

export async function dispatchDueFollowUpReminders(tenantId: number) {
  const database = await requireDatabase();
  const owner = (
    await database
      .select({ email: users.email, businessName: profiles.businessName })
      .from(profiles)
      .innerJoin(tenants, eq(profiles.tenantId, tenants.id))
      .innerJoin(users, eq(tenants.ownerUserId, users.id))
      .where(eq(profiles.tenantId, tenantId))
      .limit(1)
  )[0];
  if (!owner) return { processed: 0, notified: false };

  const dueRows = await database
    .select({ followUp: followUps, lead: leads })
    .from(followUps)
    .innerJoin(leads, and(eq(followUps.leadId, leads.id), eq(followUps.tenantId, leads.tenantId)))
    .where(
      and(
        eq(followUps.tenantId, tenantId),
        inArray(followUps.status, ["scheduled", "due"]),
        lte(followUps.dueAt, new Date()),
        isNull(followUps.reminderSentAt)
      )
    )
    .orderBy(followUps.dueAt);

  if (dueRows.length === 0) return { processed: 0, notified: false };

  const now = new Date();
  const ids = dueRows.map(row => row.followUp.id);
  await database.update(followUps).set({ status: "due" }).where(inArray(followUps.id, ids));
  const topActions = dueRows
    .slice(0, 6)
    .map(({ lead, followUp }) => `• ${lead.customerName}: ${followUp.action}`)
    .join("\n");
  const notified = await sendReminderEmail({
    to: owner.email,
    title: `${dueRows.length} follow-up${dueRows.length === 1 ? "" : "s"} due — ${owner.businessName}`,
    content: `Open the Sales Recovery Copilot to recover these conversations:\n${topActions}`,
  });

  if (notified) {
    await database
      .update(followUps)
      .set({ reminderSentAt: now })
      .where(and(eq(followUps.tenantId, tenantId), inArray(followUps.id, ids)));
  }

  return { processed: dueRows.length, notified };
}

/** Scans every tenant for due, unreminded follow-ups. Called on an in-process schedule (see server/_core/index.ts). */
export async function dispatchAllDueFollowUpReminders() {
  const database = await requireDatabase();
  const dueTenantRows = await database
    .selectDistinct({ tenantId: followUps.tenantId })
    .from(followUps)
    .where(
      and(
        inArray(followUps.status, ["scheduled", "due"]),
        lte(followUps.dueAt, new Date()),
        isNull(followUps.reminderSentAt)
      )
    );

  let processed = 0;
  let notified = 0;
  for (const { tenantId } of dueTenantRows) {
    const result = await dispatchDueFollowUpReminders(tenantId);
    processed += result.processed;
    if (result.notified) notified += 1;
  }
  return { tenantsWithDueFollowUps: dueTenantRows.length, processed, notified };
}
