import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { createUser, getUserByEmail, touchLastSignedIn } from "./db";
import { createSessionToken, hashPassword, verifyPassword, MIN_PASSWORD_LENGTH } from "./_core/auth";
import { getSessionCookieOptions } from "./_core/cookies";
import type { TrpcContext } from "./_core/context";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  analysisResultSchema,
  analyzeCustomerMessage,
  createProduct,
  getLeadDetail,
  getRecoveryDashboard,
  saveRecoveredLead,
  updateBusinessProfile,
  updateLeadFollowUp,
} from "./salesRecovery";

const followUpStatusSchema = z.enum(["scheduled", "completed", "cancelled"]);
const emailSchema = z.string().trim().toLowerCase().email();
const passwordSchema = z.string().min(MIN_PASSWORD_LENGTH).max(200);

async function issueSession(ctx: Pick<TrpcContext, "req" | "res">, userId: number, email: string) {
  const token = await createSessionToken({ userId, email });
  const cookieOptions = getSessionCookieOptions(ctx.req);
  ctx.res.cookie(COOKIE_NAME, token, { ...cookieOptions, maxAge: ONE_YEAR_MS });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    signup: publicProcedure
      .input(
        z.object({
          email: emailSchema,
          password: passwordSchema,
          name: z.string().trim().min(1).max(160),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const existing = await getUserByEmail(input.email);
        if (existing) {
          throw new TRPCError({ code: "CONFLICT", message: "An account with this email already exists." });
        }
        const passwordHash = await hashPassword(input.password);
        const user = await createUser({ email: input.email, passwordHash, name: input.name });
        if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not create the account." });
        await issueSession(ctx, user.id, user.email);
        return { id: user.id, email: user.email, name: user.name };
      }),
    login: publicProcedure
      .input(z.object({ email: emailSchema, password: z.string().min(1).max(200) }))
      .mutation(async ({ ctx, input }) => {
        const user = await getUserByEmail(input.email);
        const valid = user ? await verifyPassword(input.password, user.passwordHash) : false;
        if (!user || !valid) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Incorrect email or password." });
        }
        await issueSession(ctx, user.id, user.email);
        await touchLastSignedIn(user.id);
        return { id: user.id, email: user.email, name: user.name };
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  recovery: router({
    dashboard: protectedProcedure.query(({ ctx }) => getRecoveryDashboard(ctx.user)),
    leadDetail: protectedProcedure.input(z.object({ leadId: z.number().int().positive() })).query(({ ctx, input }) =>
      getLeadDetail(ctx.user, input.leadId)
    ),
    updateProfile: protectedProcedure
      .input(
        z.object({
          businessName: z.string().trim().min(2).max(160),
          businessContext: z.string().trim().max(1600).optional(),
          preferredLanguage: z.string().trim().min(2).max(16),
          currency: z.string().trim().min(3).max(8),
        })
      )
      .mutation(({ ctx, input }) => updateBusinessProfile(ctx.user, input)),
    createProduct: protectedProcedure
      .input(
        z.object({
          name: z.string().trim().min(2).max(180),
          description: z.string().trim().max(800).optional(),
          price: z.number().positive().max(9_999_999_999),
          stockQuantity: z.number().int().min(0).max(9_999_999),
        })
      )
      .mutation(({ ctx, input }) => createProduct(ctx.user, input)),
    analyze: protectedProcedure
      .input(z.object({ customerMessage: z.string().trim().min(3).max(5000) }))
      .mutation(({ ctx, input }) => analyzeCustomerMessage(ctx.user, input.customerMessage)),
    saveLead: protectedProcedure
      .input(
        z.object({
          customerName: z.string().trim().min(2).max(160),
          customerPhone: z.string().trim().max(48).optional(),
          source: z.enum(["whatsapp", "instagram", "other"]),
          customerMessage: z.string().trim().min(3).max(5000),
          analysis: analysisResultSchema,
          followUpAt: z.coerce.date(),
        })
      )
      .mutation(({ ctx, input }) => saveRecoveredLead(ctx.user, input)),
    updateFollowUp: protectedProcedure
      .input(
        z.object({
          followUpId: z.number().int().positive(),
          dueAt: z.coerce.date(),
          status: followUpStatusSchema,
          action: z.string().trim().min(2).max(600),
        })
      )
      .mutation(({ ctx, input }) => updateLeadFollowUp(ctx.user, input)),
  }),
});

export type AppRouter = typeof appRouter;
