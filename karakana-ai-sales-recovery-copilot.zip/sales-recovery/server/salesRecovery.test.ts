import { getTableColumns } from "drizzle-orm";
import { describe, expect, it } from "vitest";
import { aiRuns, followUps, leads, messages, products, profiles } from "../drizzle/schema";
import { analysisResultSchema } from "./salesRecovery";

describe("sales recovery analysis contract", () => {
  const validAnalysis = {
    intent: "Price inquiry",
    leadScore: 82,
    recommendedReply: "Asante kwa ujumbe wako. Naweza kuthibitisha bei na kukuuliza bidhaa unayotaka?",
    nextAction: "Confirm the product and answer the price question.",
    suggestedFollowUpHours: 4,
    detectedProduct: "",
    rationale: "The customer is asking a purchase-oriented question.",
  };

  it("accepts a bounded, complete structured AI response", () => {
    expect(analysisResultSchema.parse(validAnalysis)).toEqual(validAnalysis);
  });

  it("rejects unbounded lead scores and missing recovery guidance", () => {
    expect(() => analysisResultSchema.parse({ ...validAnalysis, leadScore: 101 })).toThrow();
    expect(() => analysisResultSchema.parse({ ...validAnalysis, nextAction: "" })).toThrow();
  });
});

describe("tenant-scoped sales recovery persistence", () => {
  it("requires a tenant identifier on every customer-business record", () => {
    for (const table of [profiles, products, leads, messages, followUps, aiRuns]) {
      expect(getTableColumns(table)).toHaveProperty("tenantId");
      expect(getTableColumns(table).tenantId.notNull).toBe(true);
    }
  });

  it("persists a first-class follow-up state and due time", () => {
    const columns = getTableColumns(followUps);
    expect(columns).toHaveProperty("dueAt");
    expect(columns).toHaveProperty("status");
    expect(columns).toHaveProperty("reminderSentAt");
  });
});
