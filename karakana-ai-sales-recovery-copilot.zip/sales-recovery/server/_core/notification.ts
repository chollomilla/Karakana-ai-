import nodemailer from "nodemailer";
import { ENV } from "./env";

export type ReminderEmail = {
  to: string;
  title: string;
  content: string;
};

let _transporter: ReturnType<typeof nodemailer.createTransport> | null = null;

function getTransporter() {
  if (_transporter) return _transporter;
  if (!ENV.smtpHost || !ENV.smtpUser || !ENV.smtpPass) return null;

  _transporter = nodemailer.createTransport({
    host: ENV.smtpHost,
    port: ENV.smtpPort,
    secure: ENV.smtpPort === 465,
    auth: { user: ENV.smtpUser, pass: ENV.smtpPass },
  });
  return _transporter;
}

/**
 * Emails the business owner about due follow-ups. Returns `true` if the
 * message was accepted by the mail server, `false` when SMTP isn't
 * configured or delivery failed — callers should treat this as best-effort
 * and never let it block the underlying workflow.
 */
export async function sendReminderEmail({ to, title, content }: ReminderEmail): Promise<boolean> {
  const transporter = getTransporter();
  if (!transporter) {
    console.warn("[Notification] SMTP is not configured (SMTP_HOST/SMTP_USER/SMTP_PASS) — skipping email:", title);
    return false;
  }

  try {
    await transporter.sendMail({
      from: ENV.smtpFrom || ENV.smtpUser,
      to,
      subject: title,
      text: content,
    });
    return true;
  } catch (error) {
    console.warn("[Notification] Failed to send reminder email:", error);
    return false;
  }
}
