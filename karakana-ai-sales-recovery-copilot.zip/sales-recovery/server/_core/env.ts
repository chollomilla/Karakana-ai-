export const ENV = {
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  isProduction: process.env.NODE_ENV === "production",

  // AI provider (OpenAI-compatible chat completions API). Defaults to
  // OpenAI's own API; point OPENAI_BASE_URL elsewhere to use a different
  // OpenAI-compatible provider (Azure OpenAI, OpenRouter, etc.) without
  // touching application code.
  openaiApiKey: process.env.OPENAI_API_KEY ?? "",
  openaiBaseUrl: process.env.OPENAI_BASE_URL ?? "https://api.openai.com",
  openaiModel: process.env.OPENAI_MODEL ?? "gpt-5-mini",

  // Outbound email for follow-up reminders (optional). If unset, reminder
  // emails are skipped with a warning instead of failing the request.
  smtpHost: process.env.SMTP_HOST ?? "",
  smtpPort: Number(process.env.SMTP_PORT ?? "587"),
  smtpUser: process.env.SMTP_USER ?? "",
  smtpPass: process.env.SMTP_PASS ?? "",
  smtpFrom: process.env.SMTP_FROM ?? "",
};
