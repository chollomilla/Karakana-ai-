import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import { COOKIE_NAME } from "@shared/const";
import { parse as parseCookie } from "cookie";
import { getUserById } from "../db";
import type { User } from "../../drizzle/schema";
import { verifySessionToken } from "./auth";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    const token = parseCookie(opts.req.headers.cookie ?? "")[COOKIE_NAME];
    if (token) {
      const session = await verifySessionToken(token);
      if (session) {
        user = (await getUserById(session.userId)) ?? null;
      }
    }
  } catch {
    // Authentication is optional for public procedures.
    user = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
