import { describe, expect, it, beforeAll } from "vitest";

beforeAll(() => {
  process.env.JWT_SECRET = "test-secret-at-least-32-characters-long";
});

describe("password hashing", () => {
  it("hashes a password and verifies it correctly", async () => {
    const { hashPassword, verifyPassword } = await import("./auth");
    const hash = await hashPassword("correct horse battery staple");
    expect(hash).not.toBe("correct horse battery staple");
    expect(await verifyPassword("correct horse battery staple", hash)).toBe(true);
    expect(await verifyPassword("wrong password", hash)).toBe(false);
  });
});

describe("session tokens", () => {
  it("issues a token that round-trips back to the same payload", async () => {
    const { createSessionToken, verifySessionToken } = await import("./auth");
    const token = await createSessionToken({ userId: 42, email: "owner@example.com" });
    const session = await verifySessionToken(token);
    expect(session).toEqual({ userId: 42, email: "owner@example.com" });
  });

  it("rejects a malformed or tampered token", async () => {
    const { verifySessionToken } = await import("./auth");
    expect(await verifySessionToken("not-a-real-token")).toBeNull();
  });
});

describe("isValidEmail", () => {
  it("accepts well-formed addresses and rejects the rest", async () => {
    const { isValidEmail } = await import("./auth");
    expect(isValidEmail("owner@example.com")).toBe(true);
    expect(isValidEmail("not-an-email")).toBe(false);
    expect(isValidEmail("missing-domain@")).toBe(false);
  });
});
