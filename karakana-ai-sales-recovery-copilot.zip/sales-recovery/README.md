# Karakana AI — Sales Recovery Copilot

An AI copilot that helps small businesses recover abandoned WhatsApp/Instagram
sales conversations: paste a customer message, get an AI-scored lead with a
recommended reply, save it, and get an automatic reminder when the follow-up
is due.

This app is fully self-contained — it does not depend on any third-party
app-builder platform. You own the auth, the AI provider key, the database,
and the hosting.

## Stack

- **Frontend:** React 19 + Vite + Tailwind, tRPC client, wouter for routing
- **Backend:** Express + tRPC, Drizzle ORM
- **Database:** MySQL (any MySQL 8+ host)
- **AI:** OpenAI-compatible chat completions API (defaults to OpenAI directly)
- **Auth:** Email + password, JWT session cookie (bcrypt for hashing)
- **Reminders:** In-process cron (`node-cron`), runs every 30 minutes, emails
  the business owner when a follow-up is due (SMTP, optional)

## Setup

1. **Install dependencies** (this repo uses pnpm; see `packageManager` in
   `package.json` for the exact version):
   ```bash
   pnpm install
   ```

2. **Configure environment variables.** Copy `.env.example` to `.env` and
   fill in real values:
   ```bash
   cp .env.example .env
   ```
   At minimum you need `DATABASE_URL`, `JWT_SECRET`, and `OPENAI_API_KEY`.
   See `.env.example` for details on every variable, including optional SMTP
   settings for email reminders.

3. **Create the database schema:**
   ```bash
   pnpm db:push
   ```
   This runs `drizzle-kit generate` + `drizzle-kit migrate` against
   `DATABASE_URL`. The full schema is in `drizzle/schema.ts`; the migration
   that creates it is `drizzle/0000_melodic_masque.sql`.

4. **Run the dev server:**
   ```bash
   pnpm dev
   ```
   Visit the printed `http://localhost:3000/` URL. The first thing you'll
   see is a sign-up form — create an account and you're in.

## Production

```bash
pnpm build   # builds client (dist/public) + server (dist/index.js)
pnpm start   # NODE_ENV=production node dist/index.js
```

Deploy anywhere that runs Node.js 20+ and can reach your MySQL database and
OpenAI (a small VPS, Railway, Render, Fly.io, etc.). No platform-specific
services are required.

## How reminders work

A cron job inside the server process runs every 30 minutes, scans **every**
tenant for follow-ups that are due and haven't been reminded about yet, and
emails the workspace owner (via SMTP, if configured) with a summary. There's
no per-user "activate reminders" step — it's on for everyone automatically.
If SMTP isn't configured, the scheduler still runs and marks follow-ups as
"due" in the app; it just skips the email and logs a warning.

## Known follow-ups / not done in this pass

- `client/src/pages/Home.tsx` is a single large file with some loosely-typed
  (`any`) local variables in a few `.map()` callbacks. It type-checks and
  works correctly, but tightening those types is a reasonable next cleanup
  pass if you're going to keep extending this file.
- There's no password-reset flow yet (only signup/login/logout). Worth
  adding before real customers start losing access to their accounts.
- Multi-user-per-tenant isn't supported (one owner per business workspace,
  enforced by a unique `tenants.ownerUserId` constraint) — fine for a solo
  SME owner, but note it if you plan to let a business invite teammates.
