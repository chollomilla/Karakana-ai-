import { trpc } from "@/lib/trpc";
import { TRPCClientError } from "@trpc/client";
import { useCallback, useMemo } from "react";

export function useAuth() {
  const utils = trpc.useUtils();

  const meQuery = trpc.auth.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: () => utils.auth.me.invalidate(),
  });

  const signupMutation = trpc.auth.signup.useMutation({
    onSuccess: () => utils.auth.me.invalidate(),
  });

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => utils.auth.me.setData(undefined, null),
  });

  const login = useCallback(
    (email: string, password: string) => loginMutation.mutateAsync({ email, password }),
    [loginMutation]
  );

  const signup = useCallback(
    (email: string, password: string, name: string) => signupMutation.mutateAsync({ email, password, name }),
    [signupMutation]
  );

  const logout = useCallback(async () => {
    try {
      await logoutMutation.mutateAsync();
    } catch (error: unknown) {
      if (error instanceof TRPCClientError && error.data?.code === "UNAUTHORIZED") return;
      throw error;
    } finally {
      utils.auth.me.setData(undefined, null);
      await utils.auth.me.invalidate();
    }
  }, [logoutMutation, utils]);

  const state = useMemo(
    () => ({
      user: meQuery.data ?? null,
      loading: meQuery.isLoading || logoutMutation.isPending,
      isAuthenticated: Boolean(meQuery.data),
    }),
    [meQuery.data, meQuery.isLoading, logoutMutation.isPending]
  );

  return {
    ...state,
    login,
    loginPending: loginMutation.isPending,
    loginError: loginMutation.error,
    signup,
    signupPending: signupMutation.isPending,
    signupError: signupMutation.error,
    logout,
    refresh: () => meQuery.refetch(),
  };
}
